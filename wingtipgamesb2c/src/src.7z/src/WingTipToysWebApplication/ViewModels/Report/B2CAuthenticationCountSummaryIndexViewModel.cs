﻿using System.Collections.Generic;

namespace WingTipToysWebApplication.ViewModels.Report
{
    public class B2CAuthenticationCountSummaryIndexViewModel
    {
        public List<B2CAuthenticationCountSummaryReportEntryViewModel> ReportEntries { get; set; }
    }
}
