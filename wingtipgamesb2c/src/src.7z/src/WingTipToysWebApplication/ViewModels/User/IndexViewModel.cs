﻿using System.Collections.Generic;

namespace WingTipToysWebApplication.ViewModels.User
{
    public class IndexViewModel
    {
        public List<UserViewModel> Users { get; set; }
    }
}
