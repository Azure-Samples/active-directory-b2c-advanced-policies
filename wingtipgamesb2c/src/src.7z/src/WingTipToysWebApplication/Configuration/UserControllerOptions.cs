﻿namespace WingTipToysWebApplication.Configuration
{
    public class UserControllerOptions
    {
        public string ActivationAction { get; set; }

        public string ActivationController { get; set; }

        public string ActivationHost { get; set; }

        public string ActivationKey { get; set; }
    }
}
