﻿namespace WingTipIdentityWebApplication.Api.Models
{
    public class AccountRecoverPasswordRequest
    {
        public string UserName { get; set; }
    }
}
