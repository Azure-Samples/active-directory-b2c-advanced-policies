﻿namespace WingTipCommon.Generators
{
    public interface IPasswordGenerator
    {
        string GeneratePassword();
    }
}
