using Microsoft.AspNetCore.Mvc;

namespace WingTipUserJourneyPlayerWebApplication.Controllers
{
    public class ConfigController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
