﻿namespace WingTipUserJourneyPlayerWebApplication
{
    public class AzureApplicationInsightsCredential
    {
        public string ApplicationId { get; set; }

        public string ApiKey { get; set; }
    }
}
