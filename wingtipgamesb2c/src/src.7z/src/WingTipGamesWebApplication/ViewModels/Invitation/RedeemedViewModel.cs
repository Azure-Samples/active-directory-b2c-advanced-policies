﻿using System.Collections.Generic;
using WingTipGamesWebApplication.Models;

namespace WingTipGamesWebApplication.ViewModels.Invitation
{
    public class RedeemedViewModel
    {
        public Game Game { get; set; }
    }
}
