﻿using System.Collections.Generic;
using WingTipGamesWebApplication.Models;

namespace WingTipGamesWebApplication.ViewModels.Activation
{
    public class RedeemedViewModel
    {
        public IEnumerable<Game> Games { get; set; }
    }
}
