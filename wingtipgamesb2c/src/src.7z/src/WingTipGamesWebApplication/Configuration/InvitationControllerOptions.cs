﻿namespace WingTipGamesWebApplication.Configuration
{
    public class InvitationControllerOptions
    {
        public string Key { get; set; }
    }
}
