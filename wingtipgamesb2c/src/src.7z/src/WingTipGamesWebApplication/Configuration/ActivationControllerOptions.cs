﻿namespace WingTipGamesWebApplication.Configuration
{
    public class ActivationControllerOptions
    {
        public string Key { get; set; }
    }
}
