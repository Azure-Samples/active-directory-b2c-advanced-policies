using Microsoft.AspNetCore.Mvc;

namespace WingTipUserJourneyPlayerWebApplication.Controllers
{
    public class TraceController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
