﻿namespace WingTipIdentityWebApplication
{
    public enum MigrationStatus
    {
        New,
        NotMigrated,
        MigratedWithoutPassword,
        MigratedWithPassword
    }
}
