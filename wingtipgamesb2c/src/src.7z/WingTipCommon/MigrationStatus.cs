﻿namespace WingTipCommon
{
    public enum MigrationStatus
    {
        New,
        NotMigrated,
        MigratedWithoutPassword,
        MigratedWithPassword
    }
}
