﻿namespace WingTipToysWebApplication
{
    public static class Constants
    {
        public static class AuthenticationSchemes
        {
            public const string ApplicationCookie = "ApplicationCookie";
        }
    }
}
