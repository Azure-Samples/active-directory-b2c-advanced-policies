﻿using System.Collections.Generic;

namespace WingTipToysWebApplication.ViewModels.Report
{
    public class B2CUserJourneySummaryEventsIndexViewModel
    {
        public List<B2CUserJourneySummaryEventsReportEntryViewModel> ReportEntries { get; set; }
    }
}
