﻿using System.Collections.Generic;

namespace WingTipToysWebApplication.ViewModels.Report
{
    public class TenantUserCountSummaryIndexViewModel
    {
        public List<TenantUserCountSummaryReportEntryViewModel> ReportEntries { get; set; }
    }
}
