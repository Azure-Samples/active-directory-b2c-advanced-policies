﻿using System.Collections.Generic;

namespace WingTipToysWebApplication.ViewModels.Report
{
    public class B2CMfaRequestCountSummaryIndexViewModel
    {
        public List<B2CMfaRequestCountSummaryReportEntryViewModel> ReportEntries { get; set; }
    }
}
