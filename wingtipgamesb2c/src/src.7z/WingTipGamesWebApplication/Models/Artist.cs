namespace WingTipGamesWebApplication.Models
{
    public class Artist
    {
        public string Name { get; set; }
    }
}
