﻿using System.Collections.Generic;
using WingTipGamesWebApplication.Models;

namespace WingTipGamesWebApplication.ViewModels.Music
{
    public class IndexViewModel
    {
        public IEnumerable<Album> NewReleaseAlbums { get; set; }
    }
}
